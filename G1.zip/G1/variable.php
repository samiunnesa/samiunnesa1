<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
samiun
<?php
$num1=140;
$num2=260;
?>

<h1>mpi</h1>

<div class="test">
<?php
echo "this is my first program in php <br>";

$result=$num1+$num2;
echo '<br>' .$result;
?>
</div>
<div class="side">
    <h4>iist</h4>
</div>
</body>
</html>