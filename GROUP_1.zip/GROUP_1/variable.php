<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>php</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>

<?php

$num1=40;
$num2=40;
$num3=40;
$num4=40;
?>


<h2>mirpur plytechnic institute</h2>


<div class="test">
   <?php
echo"this is my program in php";

$result=$num1+$num2+$num3+$num4;
echo   $result;
?>
 </div>


    <div class="side">
        <h2>mirpur-1,dhaka-1216</h2>
    </div>
</body>
</html>

